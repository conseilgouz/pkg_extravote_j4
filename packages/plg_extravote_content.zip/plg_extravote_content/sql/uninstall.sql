
DROP TABLE IF EXISTS `#__content_extravote`;
DROP TABLE IF EXISTS `#__content_extravote_user`;